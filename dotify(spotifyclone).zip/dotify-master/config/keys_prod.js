module.exports = {
  MONGO_URI: process.env.MONGO_URI,
  secretOrKey: process.env.SECRET_OR_KEY
}