const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const SongSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  artist: {
    type: String, // Updated to String based on your MongoDB structure
    required: true,
  },
  album: {
    type: String, // Updated to String based on your MongoDB structure
    required: true,
  },
  duration: {
    type: String, // Added based on your MongoDB structure
    required: true,
  },
  genre: {
    type: String, // Added based on your MongoDB structure
    required: true,
  },
  url: {
    type: String,
    required: true,
  },
  cover: {
    type: String, // Added based on your MongoDB structure
    required: true,
  },
});

module.exports = mongoose.model("songs", SongSchema);
