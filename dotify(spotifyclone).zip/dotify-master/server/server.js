const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const keys = require("../config3/keys"); // Load environment-specific keys
const db = keys.MONGO_URI; // MongoDB URI

const expressGraphQL = require("express-graphql");
const Models = require("./models/index.js");
const schema = require("./schema/schema");
const cors = require("cors");
const path = require("path");
const app = express();

// Debugging logs
console.log("NODE_ENV:", process.env.NODE_ENV || "Not Set"); // Log current environment
console.log("MongoDB URI:", db || "Not Set"); // Log MongoDB URI

// Ensure database URI is provided
if (!db) {
  throw new Error("You must provide a string to connect to MongoDB");
}

// Connect to MongoDB
mongoose
  .connect(db, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB successfully"))
  .catch(err => console.error("MongoDB Connection Error:", err));

if (process.env.NODE_ENV === "production") {
  app.use(express.static("client/build"));
  app.get("/", (req, res) => {
    res.sendFile(path.resolve(__dirname, "client", "build", "index.html"));
  });
}

app.use(cors()); // Enable CORS
app.use(bodyParser.json()); // Parse JSON requests

// Set up GraphQL middleware
app.use(
  "/graphql",
  expressGraphQL({
    schema,
    graphiql: true // Enable GraphiQL tool
  })
);

module.exports = app;
