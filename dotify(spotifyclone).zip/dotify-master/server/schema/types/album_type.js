const mongoose = require("mongoose");
const graphql = require("graphql");
const { GraphQLObjectType, GraphQLString, GraphQLID, GraphQLList } = graphql;
const Album = mongoose.model("albums");

const AlbumType = new GraphQLObjectType({
  name: "AlbumType",
  fields: () => ({
    _id: { type: GraphQLID },
    name: { type: GraphQLString },
    genre: { type: GraphQLString },
    artist: {
      type: require("./artist_type"),
      resolve(parentValue) {
        return mongoose.model("artists").findById(parentValue.artist);
      }
    },
    songs: {
      type: new GraphQLList(require("./song_type")),
      resolve(parentValue) {
        return mongoose.model("songs").find({ album: parentValue._id });
      }
    },
    url: { type: GraphQLString }
  })
});

module.exports = AlbumType;
