const mongoose = require("mongoose");
const graphql = require("graphql");
const { GraphQLObjectType, GraphQLString, GraphQLID } = graphql;

const SongType = new GraphQLObjectType({
  name: "SongType",
  fields: () => ({
    _id: { type: GraphQLID },
    title: { type: GraphQLString },
    url: { type: GraphQLString },
    cover: { type: GraphQLString },
    genre: { type: GraphQLString },
    duration: { type: GraphQLString },
    artist: {
      type: require("./artist_type"),
      resolve(parentValue) {
        return mongoose.model("artists").findById(parentValue.artist);
      }
    },
    album: {
      type: require("./album_type"),
      resolve(parentValue) {
        return mongoose.model("albums").findById(parentValue.album);
      }
    }
  })
});

module.exports = SongType;
