const mongoose = require("mongoose");
const graphql = require("graphql");
const { GraphQLObjectType, GraphQLList, GraphQLID, GraphQLNonNull, GraphQLString } = graphql;

const UserType = require("./user_type");
const SongType = require("./song_type");
const ArtistType = require("./artist_type");
const AlbumType = require("./album_type");
const SearchType = require("./search_type");
const PlaylistType = require("./playlist_type");

const User = mongoose.model("users");
const Song = mongoose.model("songs");
const Artist = mongoose.model("artists");
const Album = mongoose.model("albums");
const Playlist = mongoose.model("playlists");

const RootQueryType = new GraphQLObjectType({
  name: "RootQueryType",
  fields: () => ({
    users: {
      type: new GraphQLList(UserType),
      resolve() {
        return User.find({});
      }
    },
    songs: {
      type: new GraphQLList(SongType),
      resolve() {
        return Song.find({})
          .populate("album")
          .populate("artist")
          .then(songs => {
            console.log("Fetched songs:", songs);
            return songs;
          })
          .catch(err => console.error("Error fetching songs:", err));
      }
    },
    song: {
      type: SongType,
      args: { _id: { type: new GraphQLNonNull(GraphQLID) } },
      resolve(_, args) {
        return Song.findById(args._id)
          .populate("album")
          .populate("artist")
          .then(song => {
            console.log("Fetched song:", song);
            return song;
          })
          .catch(err => console.error("Error fetching song:", err));
      }
    }
  })
});

module.exports = RootQueryType;
