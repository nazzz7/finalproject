module.exports = {
    MONGO_URI: "mongodb://localhost:27017/spotifyclone", // Use a local development MongoDB URI
    secretOrKey: "secretkey1234" // Use a secret key for development purposes
  }
  