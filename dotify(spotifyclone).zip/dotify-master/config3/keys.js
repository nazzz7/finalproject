if (process.env.NODE_ENV === 'production') {
  module.exports = require('./keys_prod'); // Use production keys
} else if (process.env.NODE_ENV === 'development') {
  module.exports = require('./keys_dev'); // Use development keys
} else {
  // Default fallback (development keys)
  console.warn("NODE_ENV not set, defaulting to development keys.");
  module.exports = require('./keys_dev');
}
